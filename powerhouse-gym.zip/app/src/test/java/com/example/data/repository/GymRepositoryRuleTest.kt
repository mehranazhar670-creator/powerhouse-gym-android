package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.CallOutcome
import com.example.data.model.PromoPlatform
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class GymRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun addAndObserveContacts_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser("owner_${UUID.randomUUID()}@gym.test")
        val repo = GymRepository(firestore)

        val addRes = withTimeout(TIMEOUT_MS) {
            repo.addContact(
                userId = uid,
                name = "Aarav Verma",
                phone = "+919988776655",
                goal = "Strength",
                notes = "Morning shift"
            )
        }
        assertTrue(addRes.isSuccess)
        val contactId = addRes.getOrThrow()

        val contacts = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeContacts(uid).first { list -> list.any { it.id == contactId } }
        }
        assertTrue(contacts.any { it.id == contactId && it.name == "Aarav Verma" })

        val updateRes = withTimeout(TIMEOUT_MS) {
            repo.updateMemberLead(
                userId = uid,
                contactId = contactId,
                name = "Aarav Verma Jr",
                phone = "+919988776600",
                goal = "Personal Training",
                status = com.example.data.model.ContactStatus.INTERESTED,
                notes = "Confirmed evening trial"
            )
        }
        assertTrue(updateRes.isSuccess)

        val updated = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeContacts(uid).first { list ->
                list.any {
                    it.id == contactId &&
                        it.name == "Aarav Verma Jr" &&
                        it.phone == "+919988776600" &&
                        it.status == com.example.data.model.ContactStatus.INTERESTED
                }
            }
        }
        assertTrue(updated.isNotEmpty())
    }

    @Test
    fun recordInvitationCall_enforcesMaxTwoCallsDaily() = runBlocking {
        val uid = signInTestUser("quota_${UUID.randomUUID()}@gym.test")
        val repo = GymRepository(firestore)
        val dateKey = "2026-11-15"

        val c1Id = withTimeout(TIMEOUT_MS) {
            repo.addContact(uid, "Lead One", "+15550001001", "Strength").getOrThrow()
        }
        val c2Id = withTimeout(TIMEOUT_MS) {
            repo.addContact(uid, "Lead Two", "+15550001002", "Weight Loss").getOrThrow()
        }
        val c3Id = withTimeout(TIMEOUT_MS) {
            repo.addContact(uid, "Lead Three", "+15550001003", "Cardio & HIIT").getOrThrow()
        }

        val contacts = withTimeout(TIMEOUT_MS) { repo.getContacts(uid).getOrThrow() }
        val c1 = contacts.first { it.id == c1Id }
        val c2 = contacts.first { it.id == c2Id }
        val c3 = contacts.first { it.id == c3Id }

        val call1 = withTimeout(TIMEOUT_MS) {
            repo.recordInvitationCall(uid, c1, dateKey, CallOutcome.ATTENDED, "Invited to VIP week", 32)
        }
        assertTrue(call1.isSuccess)

        val call2 = withTimeout(TIMEOUT_MS) {
            repo.recordInvitationCall(uid, c2, dateKey, CallOutcome.INTERESTED, "Booked tour", 45)
        }
        assertTrue(call2.isSuccess)

        // 3rd invitation call on the same day MUST be rejected
        val call3 = withTimeout(TIMEOUT_MS) {
            repo.recordInvitationCall(uid, c3, dateKey, CallOutcome.ATTENDED, "Should fail", 20)
        }
        assertTrue(call3.isFailure)

        val quota = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeDailyQuota(uid, dateKey).first { it.callsAttended == 2L }
        }
        assertEquals(2L, quota.callsAttended)
    }

    @Test
    fun markPosterAndShareReel_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser("promo_${UUID.randomUUID()}@gym.test")
        val repo = GymRepository(firestore)
        val dateKey = "2026-11-15"

        val contactId = withTimeout(TIMEOUT_MS) {
            repo.addContact(uid, "Maya Singh", "+15550002222", "Personal Training").getOrThrow()
        }

        val posterRes = withTimeout(TIMEOUT_MS) {
            repo.markPosterSent(uid, contactId, dateKey)
        }
        assertTrue(posterRes.isSuccess)

        val reelRes = withTimeout(TIMEOUT_MS) {
            repo.saveAndTrackPromoShare(
                userId = uid,
                platform = PromoPlatform.INSTAGRAM_REEL,
                headline = "UNLEASH YOUR POWER",
                caption = "7-Day VIP Trial at PowerHouse Gym",
                reelHook = "Stop skipping leg day!",
                hashtags = "#PowerHouseGym #GymReels",
                templateIndex = 0,
                dateKey = dateKey
            )
        }
        assertTrue(reelRes.isSuccess)
    }

    @Test
    fun crossUserAccess_contactsDeniedWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@gym.test")
        val aliceRepo = GymRepository(firestore)
        withTimeout(TIMEOUT_MS) {
            aliceRepo.addContact(aliceUid, "Private Lead", "+15559990000", "Strength").getOrThrow()
        }

        signInTestUser("bob_${UUID.randomUUID()}@gym.test")
        val bobRepo = GymRepository(firestore)
        val result = withTimeout(TIMEOUT_MS) {
            bobRepo.getContacts(aliceUid)
        }
        assertTrue(result.isFailure)
        val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun unauthenticatedUser_observeContactsFailsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = GymRepository(firestore)
        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeContacts("some_user_id").first()
            }
        } catch (e: Exception) {
            caught = e
        }
        val fsEx = caught?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    private companion object {
        const val TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
