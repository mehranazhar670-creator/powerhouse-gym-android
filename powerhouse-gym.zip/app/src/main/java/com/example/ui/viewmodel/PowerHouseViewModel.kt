package com.example.ui.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiCallScript
import com.example.data.ai.GymAiService
import com.example.data.model.CallLog
import com.example.data.model.DailyQuota
import com.example.data.model.GymContact
import com.example.data.model.PromoCampaign
import com.example.data.model.PromoPlatform
import com.example.data.repository.GymRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface DataUiState<out T> {
    data object Loading : DataUiState<Nothing>
    data class Success<T>(val data: T) : DataUiState<T>
    data class Error(val message: String) : DataUiState<Nothing>
}

data class AiCallUiState(
    val selectedContact: GymContact? = null,
    val selectedOffer: String = "Free 7-Day VIP Pass + Body Assessment",
    val isGenerating: Boolean = false,
    val script: AiCallScript? = null,
    val liveReply: String? = null,
    val isGeneratingReply: Boolean = false,
    val callStartTimeMs: Long = 0L,
    val isLoggingCall: Boolean = false,
    val error: String? = null,
    val statusBanner: String? = null
)

data class WhatsAppStudioState(
    val templateIndex: Int = 0,
    val headline: String = "UNLEASH YOUR POWER",
    val badgeText: String = "FREE 7-DAY VIP PASS",
    val offerDetails: String = "24/7 Strength Zone • HIIT Studio • Personal Trainers",
    val clubContact: String = "CALL OR VISIT POWERHOUSE GYM TODAY",
    val whatsappMessage: String = "Hey! PowerHouse Gym invites you for a FREE 7-Day VIP Trial Pass. Check out our poster and reply to book your first session!",
    val targetContactId: String? = null,
    val isGeneratingAi: Boolean = false,
    val error: String? = null
)

data class SocialStudioState(
    val selectedPlatform: String = PromoPlatform.INSTAGRAM_REEL,
    val templateIndex: Int = 1,
    val themeInput: String = "Early Morning Transformation & 7-Day Free Trial",
    val offerInput: String = "Zero Joining Fee + Free Coach Onboarding This Week",
    val headline: String = "NO EXCUSES. ONLY RESULTS.",
    val reelHook: String = "POV: You finally stepped into PowerHouse Gym at 6 AM and changed your whole week.",
    val shotList: String = "1. Wide slow-mo barbell rack reveal (0-3s)\n2. High-energy battle ropes sprint cut (3-8s)\n3. Coach fist-bump + VIP trial overlay CTA (8-15s)",
    val caption: String = "Ready to upgrade your training? Claim your FREE 7-Day VIP Pass at PowerHouse Gym this week—Zero Joining Fee for new members!",
    val hashtags: String = "#PowerHouseGym #GymReels #FitnessMotivation #StrengthTraining #HIITWorkout #GymCommunity",
    val selectedVideoUri: Uri? = null,
    val isGeneratingAi: Boolean = false,
    val error: String? = null
)

class PowerHouseViewModel(
    private val repository: GymRepository,
    private val aiService: GymAiService,
    val currentUserId: String
) : ViewModel() {

    val todayKey: String = GymRepository.todayDateKey()

    val contactsState: StateFlow<DataUiState<List<GymContact>>> =
        repository.observeContacts(currentUserId)
            .map<List<GymContact>, DataUiState<List<GymContact>>> { DataUiState.Success(it) }
            .catch { error ->
                val fsErr = unwrapFirestoreError(error)
                if (fsErr == null && error is CancellationException) throw error
                val root = fsErr ?: error
                Log.w(TAG, "Failed observing contacts", root)
                emit(DataUiState.Error(root.message ?: "Failed to load contacts"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = DataUiState.Loading
            )

    val dailyQuotaState: StateFlow<DailyQuota> =
        repository.observeDailyQuota(currentUserId, todayKey)
            .catch { error ->
                val fsErr = unwrapFirestoreError(error)
                if (fsErr == null && error is CancellationException) throw error
                Log.w(TAG, "Failed observing daily quota", fsErr ?: error)
                emit(DailyQuota(id = todayKey, userId = currentUserId, dateKey = todayKey))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = DailyQuota(id = todayKey, userId = currentUserId, dateKey = todayKey)
            )

    val callLogsState: StateFlow<List<CallLog>> =
        repository.observeCallLogs(currentUserId)
            .catch { error ->
                val fsErr = unwrapFirestoreError(error)
                if (fsErr == null && error is CancellationException) throw error
                Log.w(TAG, "Failed observing call logs", fsErr ?: error)
                emit(emptyList())
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    val promoCampaignsState: StateFlow<List<PromoCampaign>> =
        repository.observePromoCampaigns(currentUserId)
            .catch { error ->
                val fsErr = unwrapFirestoreError(error)
                if (fsErr == null && error is CancellationException) throw error
                Log.w(TAG, "Failed observing promo campaigns", fsErr ?: error)
                emit(emptyList())
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    private val _aiCallState = MutableStateFlow(AiCallUiState())
    val aiCallState: StateFlow<AiCallUiState> = _aiCallState.asStateFlow()

    private val _whatsAppState = MutableStateFlow(WhatsAppStudioState())
    val whatsAppState: StateFlow<WhatsAppStudioState> = _whatsAppState.asStateFlow()

    private val _socialState = MutableStateFlow(SocialStudioState())
    val socialState: StateFlow<SocialStudioState> = _socialState.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    fun consumeFeedback() {
        _feedbackMessage.value = null
    }

    fun selectContactForAiCall(contact: GymContact) {
        _aiCallState.update {
            it.copy(
                selectedContact = contact,
                script = null,
                liveReply = null,
                error = null,
                statusBanner = null
            )
        }
    }

    fun updateCallOffer(offer: String) {
        _aiCallState.update { it.copy(selectedOffer = offer) }
    }

    fun generateAiInvitationCall(contact: GymContact) {
        val currentAttended = dailyQuotaState.value.callsAttended
        if (currentAttended >= GymRepository.MAX_DAILY_INVITATION_CALLS) {
            _aiCallState.update {
                it.copy(
                    selectedContact = contact,
                    error = "Daily limit of 2 attended invitation calls reached for today."
                )
            }
            return
        }

        viewModelScope.launch {
            _aiCallState.update {
                it.copy(
                    selectedContact = contact,
                    isGenerating = true,
                    error = null,
                    liveReply = null,
                    statusBanner = null,
                    callStartTimeMs = System.currentTimeMillis()
                )
            }
            val result = aiService.generateCallScript(
                contactName = contact.name,
                goal = contact.goal,
                gymOffer = _aiCallState.value.selectedOffer
            )
            result.fold(
                onSuccess = { script ->
                    _aiCallState.update {
                        it.copy(
                            isGenerating = false,
                            script = script,
                            statusBanner = "AI invitation script ready for ${contact.name}"
                        )
                    }
                },
                onFailure = { err ->
                    _aiCallState.update {
                        it.copy(
                            isGenerating = false,
                            error = err.localizedMessage ?: "Failed to generate AI invitation script."
                        )
                    }
                }
            )
        }
    }

    fun askLiveObjectionReply(question: String) {
        val contact = _aiCallState.value.selectedContact ?: return
        if (question.isBlank()) return
        viewModelScope.launch {
            _aiCallState.update { it.copy(isGeneratingReply = true, error = null) }
            val result = aiService.generateLiveObjectionReply(
                contactName = contact.name,
                goal = contact.goal,
                clientQuestion = question
            )
            result.fold(
                onSuccess = { reply ->
                    _aiCallState.update { it.copy(isGeneratingReply = false, liveReply = reply) }
                },
                onFailure = { err ->
                    _aiCallState.update {
                        it.copy(
                            isGeneratingReply = false,
                            error = err.localizedMessage ?: "Failed to generate reply."
                        )
                    }
                }
            )
        }
    }

    fun logAiCallOutcome(outcome: String) {
        val state = _aiCallState.value
        val contact = state.selectedContact ?: return
        val elapsedSec = if (state.callStartTimeMs > 0L) {
            ((System.currentTimeMillis() - state.callStartTimeMs) / 1000L).toInt().coerceIn(5, 3600)
        } else {
            25
        }
        val summary = state.script?.summary ?: "PowerHouse Gym VIP invitation call"

        viewModelScope.launch {
            _aiCallState.update { it.copy(isLoggingCall = true, error = null) }
            val res = repository.recordInvitationCall(
                userId = currentUserId,
                contact = contact,
                dateKey = todayKey,
                outcome = outcome,
                aiScriptSummary = summary,
                durationSeconds = elapsedSec
            )
            res.fold(
                onSuccess = {
                    _aiCallState.update {
                        it.copy(
                            isLoggingCall = false,
                            statusBanner = "Call logged (${outcome.uppercase()}) for ${contact.name}."
                        )
                    }
                    _feedbackMessage.value = "Invitation call logged for ${contact.name}"
                },
                onFailure = { err ->
                    _aiCallState.update {
                        it.copy(
                            isLoggingCall = false,
                            error = err.localizedMessage ?: "Unable to log call."
                        )
                    }
                }
            )
        }
    }

    fun addSingleContact(name: String, phone: String, goal: String, notes: String) {
        viewModelScope.launch {
            val res = repository.addContact(currentUserId, name, phone, goal, notes)
            res.fold(
                onSuccess = { _feedbackMessage.value = "Added $name to contacts" },
                onFailure = { _feedbackMessage.value = it.localizedMessage ?: "Failed to add contact" }
            )
        }
    }

    fun importContactsFromText(rawText: String, defaultGoal: String) {
        val entries = parseBulkContactsText(rawText)
        if (entries.isEmpty()) {
            _feedbackMessage.value = "No valid rows found. Use 'Name, +Phone' per line."
            return
        }
        viewModelScope.launch {
            val res = repository.importContactsBulk(currentUserId, entries, defaultGoal)
            res.fold(
                onSuccess = { count ->
                    _feedbackMessage.value = "Imported $count contacts (up to 1,000 cap)"
                },
                onFailure = { err ->
                    _feedbackMessage.value = err.localizedMessage ?: "Import failed"
                }
            )
        }
    }

    fun deleteContact(contactId: String) {
        viewModelScope.launch {
            val res = repository.deleteContact(currentUserId, contactId)
            res.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Delete failed"
            }
        }
    }

    fun updateMemberLead(
        contactId: String,
        name: String,
        phone: String,
        goal: String,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val res = repository.updateMemberLead(
                userId = currentUserId,
                contactId = contactId,
                name = name,
                phone = phone,
                goal = goal,
                status = status,
                notes = notes
            )
            res.onSuccess {
                _feedbackMessage.value = "Updated $name"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Failed to update member"
            }
        }
    }

    fun quickUpdateInvitationStatus(contact: GymContact, newStatus: String) {
        viewModelScope.launch {
            val res = repository.updateContactStatus(
                userId = currentUserId,
                contact = contact,
                newStatus = newStatus
            )
            res.onSuccess {
                _feedbackMessage.value = "${contact.name} marked as ${com.example.data.model.ContactStatus.label(newStatus)}"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Failed to update status"
            }
        }
    }

    fun updateWhatsAppStudio(transform: (WhatsAppStudioState) -> WhatsAppStudioState) {
        _whatsAppState.update(transform)
    }

    fun generateAiWhatsAppCopy(offerTheme: String, contactName: String?) {
        viewModelScope.launch {
            _whatsAppState.update { it.copy(isGeneratingAi = true, error = null) }
            val res = aiService.generateWhatsAppPosterCopy(offerTheme, contactName)
            res.fold(
                onSuccess = { copy ->
                    _whatsAppState.update {
                        it.copy(
                            isGeneratingAi = false,
                            headline = copy.posterHeadline,
                            badgeText = copy.badgeText,
                            whatsappMessage = copy.whatsappMessage
                        )
                    }
                },
                onFailure = { err ->
                    _whatsAppState.update {
                        it.copy(
                            isGeneratingAi = false,
                            error = err.localizedMessage ?: "AI poster copy failed"
                        )
                    }
                }
            )
        }
    }

    fun markWhatsAppPosterDispatched(contactId: String?) {
        viewModelScope.launch {
            val res = repository.markPosterSent(currentUserId, contactId, todayKey)
            res.onSuccess {
                _feedbackMessage.value = "WhatsApp poster dispatch recorded"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Failed to record poster"
            }
        }
    }

    fun updateSocialStudio(transform: (SocialStudioState) -> SocialStudioState) {
        _socialState.update(transform)
    }

    fun generateAiSocialKit() {
        val current = _socialState.value
        val platformLabel = if (current.selectedPlatform == PromoPlatform.INSTAGRAM_REEL) {
            "Instagram Reels"
        } else {
            "Facebook Page Post & Reel"
        }
        viewModelScope.launch {
            _socialState.update { it.copy(isGeneratingAi = true, error = null) }
            val res = aiService.generateSocialPromoKit(
                platformLabel = platformLabel,
                gymOffer = current.offerInput,
                theme = current.themeInput
            )
            res.fold(
                onSuccess = { kit ->
                    _socialState.update {
                        it.copy(
                            isGeneratingAi = false,
                            headline = kit.headline,
                            reelHook = kit.reelHook,
                            shotList = kit.shotList,
                            caption = kit.caption,
                            hashtags = kit.hashtags
                        )
                    }
                },
                onFailure = { err ->
                    _socialState.update {
                        it.copy(
                            isGeneratingAi = false,
                            error = err.localizedMessage ?: "AI Reels kit failed"
                        )
                    }
                }
            )
        }
    }

    fun recordSocialShare(platform: String) {
        val s = _socialState.value
        viewModelScope.launch {
            val res = repository.saveAndTrackPromoShare(
                userId = currentUserId,
                platform = platform,
                headline = s.headline,
                caption = s.caption,
                reelHook = s.reelHook,
                hashtags = s.hashtags,
                templateIndex = s.templateIndex,
                dateKey = todayKey
            )
            res.onSuccess {
                _feedbackMessage.value = "Shared campaign saved to history"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Failed saving share"
            }
        }
    }

    private fun parseBulkContactsText(rawText: String): List<Pair<String, String>> {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
        // Check if VCF format
        if (lines.any { it.startsWith("BEGIN:VCARD", ignoreCase = true) }) {
            val parsed = mutableListOf<Pair<String, String>>()
            var currentName = ""
            var currentPhone = ""
            for (line in lines) {
                when {
                    line.startsWith("FN:", ignoreCase = true) -> {
                        currentName = line.substringAfter(":").trim()
                    }
                    line.startsWith("TEL", ignoreCase = true) -> {
                        currentPhone = line.substringAfter(":").trim()
                    }
                    line.startsWith("END:VCARD", ignoreCase = true) -> {
                        if (currentName.isNotBlank() && currentPhone.length >= 5) {
                            parsed.add(currentName to currentPhone)
                        }
                        currentName = ""
                        currentPhone = ""
                    }
                }
            }
            return parsed
        }

        // Standard CSV or Name, Phone lines
        return lines.mapNotNull { line ->
            val parts = line.split(',', ';', '\t').map { it.trim().trim('"') }
            if (parts.size >= 2) {
                val name = parts[0]
                val phone = parts[1]
                if (name.equals("name", ignoreCase = true) && phone.equals("phone", ignoreCase = true)) {
                    null
                } else {
                    name to phone
                }
            } else {
                null
            }
        }
    }

    private fun unwrapFirestoreError(error: Throwable): FirebaseFirestoreException? {
        return generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
    }

    private companion object {
        const val TAG = "PowerHouseVM"
    }
}
