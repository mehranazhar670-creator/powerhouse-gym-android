package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PowerHouseDarkColorScheme = darkColorScheme(
    primary = VoltLime,
    onPrimary = ObsidianBg,
    primaryContainer = Color(0xFF283300),
    onPrimaryContainer = VoltLime,
    secondary = PowerOrange,
    onSecondary = Color.White,
    secondaryContainer = PowerOrangeContainer,
    onSecondaryContainer = Color(0xFFFFB59D),
    tertiary = CyanPulse,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = CarbonSurface,
    onSurface = TextPrimary,
    surfaceVariant = CarbonSurfaceHigh,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = CarbonSurface,
    surfaceContainer = CarbonSurfaceHigh,
    surfaceContainerHigh = CarbonSurfaceHighest,
    outline = CarbonBorder,
    outlineVariant = Color(0xFF232A36),
    error = ErrorCoral,
    onError = Color.White
)

private val PowerHouseShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PowerHouseGymTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PowerHouseDarkColorScheme,
        typography = PowerHouseTypography,
        shapes = PowerHouseShapes,
        content = content
    )
}
