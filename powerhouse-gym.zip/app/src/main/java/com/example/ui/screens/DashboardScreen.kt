package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CallLog
import com.example.data.model.CallOutcome
import com.example.data.model.ContactStatus
import com.example.data.model.DailyQuota
import com.example.data.model.GymContact
import com.example.data.repository.GymRepository
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceHigh
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramRose
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PowerOrange
import com.example.ui.theme.VoltLime
import com.example.ui.theme.WhatsAppGreen

@Composable
fun DashboardScreen(
    contacts: List<GymContact>,
    dailyQuota: DailyQuota,
    callLogs: List<CallLog>,
    onNavigateToCaller: () -> Unit,
    onNavigateToContacts: () -> Unit,
    onNavigateToWhatsAppPromo: () -> Unit,
    onNavigateToReelsPromo: () -> Unit,
    onSignOut: () -> Unit
) {
    val callsUsed = dailyQuota.callsAttended.toInt().coerceIn(0, GymRepository.MAX_DAILY_INVITATION_CALLS)
    val callsRemaining = (GymRepository.MAX_DAILY_INVITATION_CALLS - callsUsed).coerceAtLeast(0)
    val contactCount = contacts.size
    val interestedCount = contacts.count {
        it.status == ContactStatus.INTERESTED || it.status == ContactStatus.JOINED
    }
    val postersSentTotal = contacts.count { it.posterSent }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "POWERHOUSE GYM",
                            style = MaterialTheme.typography.headlineLarge,
                            color = VoltLime
                        )
                        Text(
                            text = "Daily AI Outreach & Growth Hub",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(CarbonSurface)
                            .border(1.dp, CarbonBorder, CircleShape)
                            .testTag("sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign out",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Hero Daily AI Call Limit Card (Max 2 daily attended calls)
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CarbonBorder, RoundedCornerShape(22.dp))
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_gym),
                            contentDescription = "PowerHouse Gym training floor",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            ObsidianBg.copy(alpha = 0.45f),
                                            ObsidianBg.copy(alpha = 0.94f)
                                        )
                                    )
                                )
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = if (callsRemaining > 0) VoltLime.copy(alpha = 0.2f) else PowerOrange.copy(alpha = 0.24f),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = if (callsRemaining > 0) "$callsRemaining CALLS LEFT TODAY" else "DAILY 2/2 QUOTA COMPLETE",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (callsRemaining > 0) VoltLime else PowerOrange,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }

                                Text(
                                    text = "$callsUsed / ${GymRepository.MAX_DAILY_INVITATION_CALLS} Attended",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "AUTO AI MEMBER INVITATION CALLER",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White
                            )

                            LinearProgressIndicator(
                                progress = { callsUsed.toFloat() / GymRepository.MAX_DAILY_INVITATION_CALLS.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp)),
                                color = if (callsRemaining > 0) VoltLime else PowerOrange,
                                trackColor = Color.White.copy(alpha = 0.16f),
                                strokeCap = StrokeCap.Round
                            )

                            Button(
                                onClick = onNavigateToCaller,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VoltLime,
                                    contentColor = ObsidianBg
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("dashboard_launch_ai_call")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Call,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (callsRemaining > 0) "Start AI Invitation Call" else "View Daily Call Logs",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 1,000 Contact Capacity Meter + Quick KPI Row
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CarbonBorder, RoundedCornerShape(18.dp))
                        .clickable { onNavigateToContacts() }
                        .testTag("dashboard_contacts_capacity_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Contacts,
                                    contentDescription = null,
                                    tint = PowerOrange
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Member Lead Contacts",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "$contactCount / ${GymRepository.MAX_CONTACTS}",
                                style = MaterialTheme.typography.titleMedium,
                                color = VoltLime,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        LinearProgressIndicator(
                            progress = { (contactCount.toFloat() / GymRepository.MAX_CONTACTS.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = PowerOrange,
                            trackColor = CarbonSurfaceHigh,
                            strokeCap = StrokeCap.Round
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MiniStat(label = "Posters Sent", value = "$postersSentTotal", accent = WhatsAppGreen)
                            MiniStat(label = "Reels Shared", value = "${dailyQuota.reelsShared}", accent = InstagramRose)
                            MiniStat(label = "Interested", value = "$interestedCount", accent = VoltLime)
                        }
                    }
                }
            }

            // Channel Launch Grid
            item {
                Text(
                    text = "OUTREACH CHANNELS",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ChannelActionCard(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_whatsapp_card"),
                        icon = Icons.Filled.Campaign,
                        accent = WhatsAppGreen,
                        title = "WhatsApp Poster",
                        subtitle = "Send promo poster to leads",
                        onClick = onNavigateToWhatsAppPromo
                    )
                    ChannelActionCard(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_reels_card"),
                        icon = Icons.Filled.PlayArrow,
                        accent = InstagramRose,
                        title = "IG & FB Reels",
                        subtitle = "AI hooks & direct share",
                        onClick = onNavigateToReelsPromo
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ChannelActionCard(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_import_contacts_card"),
                        icon = Icons.Filled.Contacts,
                        accent = PowerOrange,
                        title = "Add 1,000 Leads",
                        subtitle = "CSV, VCF or bulk paste",
                        onClick = onNavigateToContacts
                    )
                    ChannelActionCard(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_facebook_card"),
                        icon = Icons.Filled.Share,
                        accent = FacebookBlue,
                        title = "Facebook Promo",
                        subtitle = "Boost local gym posts",
                        onClick = onNavigateToReelsPromo
                    )
                }
            }

            // Recent AI Call Logs
            item {
                Text(
                    text = "RECENT AI INVITATION CALLS",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (callLogs.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CarbonBorder, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = VoltLime
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "No AI calls logged yet today. Add leads and launch your first invitation call (up to 2 daily).",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(callLogs.take(5), key = { it.id }) { log ->
                    CallLogRow(log = log)
                }
            }
        }
    }
}

@Composable
private fun MiniStat(
    label: String,
    value: String,
    accent: Color
) {
    Column {
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = accent,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ChannelActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    accent: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        modifier = modifier
            .border(1.dp, CarbonBorder, RoundedCornerShape(18.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CallLogRow(log: CallLog) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CarbonBorder, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = if (log.outcome == CallOutcome.INTERESTED || log.outcome == CallOutcome.ATTENDED) VoltLime else PowerOrange,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${log.contactName} • ${CallOutcome.label(log.outcome)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = log.aiScriptSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = log.dateKey,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
