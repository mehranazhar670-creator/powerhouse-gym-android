package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0B0D10)
val CarbonSurface = Color(0xFF13171E)
val CarbonSurfaceHigh = Color(0xFF1B212B)
val CarbonSurfaceHighest = Color(0xFF252D3A)
val CarbonBorder = Color(0xFF2E3847)

val VoltLime = Color(0xFFD4FF00)
val VoltLimeDim = Color(0xFFA3C700)
val PowerOrange = Color(0xFFFF5A1F)
val PowerOrangeContainer = Color(0xFF3A1A0E)
val CyanPulse = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFF4F6FA)
val TextSecondary = Color(0xFF9BA6B8)
val ErrorCoral = Color(0xFFFF5252)

val WhatsAppGreen = Color(0xFF25D366)
val InstagramRose = Color(0xFFE1306C)
val FacebookBlue = Color(0xFF1877F2)
