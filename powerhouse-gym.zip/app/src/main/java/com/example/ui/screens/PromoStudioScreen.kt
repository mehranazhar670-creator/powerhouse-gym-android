package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.GymContact
import com.example.data.model.PromoPlatform
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceHigh
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramRose
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.VoltLime
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.viewmodel.SocialStudioState
import com.example.ui.viewmodel.WhatsAppStudioState
import com.example.util.PosterRendererAndShareHelper
import com.example.util.PosterTemplates

@Composable
fun PromoStudioScreen(
    selectedTabIndex: Int,
    onSelectTab: (Int) -> Unit,
    contacts: List<GymContact>,
    whatsAppState: WhatsAppStudioState,
    socialState: SocialStudioState,
    onUpdateWhatsApp: ((WhatsAppStudioState) -> WhatsAppStudioState) -> Unit,
    onGenerateAiWhatsApp: (String, String?) -> Unit,
    onRecordWhatsAppSent: (String?) -> Unit,
    onUpdateSocial: ((SocialStudioState) -> SocialStudioState) -> Unit,
    onGenerateAiSocial: () -> Unit,
    onRecordSocialShare: (String) -> Unit
) {
    val context = LocalContext.current
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        onUpdateSocial { it.copy(selectedVideoUri = uri) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "POSTER & REELS STUDIO",
                        style = MaterialTheme.typography.headlineLarge,
                        color = VoltLime
                    )
                    Text(
                        text = "Send branded gym posters on WhatsApp & promote Reels on Instagram & Facebook",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = CarbonSurface,
                    contentColor = VoltLime,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, CarbonBorder, RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { onSelectTab(0) },
                        text = { Text("WhatsApp Poster", fontWeight = FontWeight.SemiBold) },
                        modifier = Modifier.testTag("promo_tab_whatsapp")
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { onSelectTab(1) },
                        text = { Text("FB & IG Reels", fontWeight = FontWeight.SemiBold) },
                        modifier = Modifier.testTag("promo_tab_reels")
                    )
                }
            }

            if (selectedTabIndex == 0) {
                // WHATSAPP POSTER TAB
                val targetContact = contacts.firstOrNull { it.id == whatsAppState.targetContactId }
                    ?: contacts.firstOrNull { !it.posterSent }
                    ?: contacts.firstOrNull()

                item {
                    PosterPreviewCard(
                        templateIndex = whatsAppState.templateIndex,
                        badgeText = whatsAppState.badgeText,
                        headline = whatsAppState.headline,
                        offerDetails = whatsAppState.offerDetails,
                        footerCta = whatsAppState.clubContact
                    )
                }

                item {
                    TemplateSelectorRow(
                        selectedIndex = whatsAppState.templateIndex,
                        onSelect = { idx -> onUpdateWhatsApp { it.copy(templateIndex = idx) } }
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CarbonBorder, RoundedCornerShape(18.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "CUSTOMIZE POSTER & MESSAGE",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = VoltLime,
                                    fontWeight = FontWeight.Bold
                                )
                                Button(
                                    onClick = {
                                        onGenerateAiWhatsApp(whatsAppState.offerDetails, targetContact?.name)
                                    },
                                    enabled = !whatsAppState.isGeneratingAi,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VoltLime.copy(alpha = 0.18f),
                                        contentColor = VoltLime
                                    ),
                                    modifier = Modifier.height(48.dp).testTag("ai_whatsapp_copy_btn")
                                ) {
                                    if (whatsAppState.isGeneratingAi) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = VoltLime)
                                    } else {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Copy")
                                    }
                                }
                            }

                            if (whatsAppState.error != null) {
                                Text(
                                    text = whatsAppState.error,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            OutlinedTextField(
                                value = whatsAppState.badgeText,
                                onValueChange = { v -> onUpdateWhatsApp { it.copy(badgeText = v) } },
                                label = { Text("Offer Badge") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = whatsAppState.headline,
                                onValueChange = { v -> onUpdateWhatsApp { it.copy(headline = v) } },
                                label = { Text("Poster Headline") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = whatsAppState.offerDetails,
                                onValueChange = { v -> onUpdateWhatsApp { it.copy(offerDetails = v) } },
                                label = { Text("Club Highlights") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = whatsAppState.whatsappMessage,
                                onValueChange = { v -> onUpdateWhatsApp { it.copy(whatsappMessage = v) } },
                                label = { Text("WhatsApp Invitation Caption") },
                                minLines = 3,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Target Lead Picker for WhatsApp
                if (contacts.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "TARGET CONTACT (${contacts.count { !it.posterSent }} UNSENT)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                contacts.take(25).forEach { contact ->
                                    val selected = targetContact?.id == contact.id
                                    FilterChip(
                                        selected = selected,
                                        onClick = { onUpdateWhatsApp { it.copy(targetContactId = contact.id) } },
                                        label = {
                                            Text(
                                                text = if (contact.posterSent) "${contact.name} ✓" else contact.name
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = WhatsAppGreen,
                                            selectedLabelColor = ObsidianBg
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val bmp = PosterRendererAndShareHelper.renderPosterBitmap(
                                    context = context,
                                    templateIndex = whatsAppState.templateIndex,
                                    headline = whatsAppState.headline,
                                    badgeText = whatsAppState.badgeText,
                                    offerDetails = whatsAppState.offerDetails,
                                    clubContact = whatsAppState.clubContact
                                )
                                val uri = PosterRendererAndShareHelper.savePosterToCacheUri(context, bmp)
                                bmp.recycle()
                                PosterRendererAndShareHelper.sharePosterToWhatsApp(
                                    context = context,
                                    posterUri = uri,
                                    message = whatsAppState.whatsappMessage,
                                    targetPhone = targetContact?.phone
                                )
                                onRecordWhatsAppSent(targetContact?.id)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = ObsidianBg
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("send_whatsapp_poster_btn")
                        ) {
                            Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (targetContact != null) {
                                    "Send Poster to ${targetContact.name} on WhatsApp"
                                } else {
                                    "Send Poster on WhatsApp"
                                },
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (targetContact != null) {
                            OutlinedButton(
                                onClick = {
                                    PosterRendererAndShareHelper.openWhatsAppDirectChat(
                                        context = context,
                                        phone = targetContact.phone,
                                        message = whatsAppState.whatsappMessage
                                    )
                                    onRecordWhatsAppSent(targetContact.id)
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("whatsapp_direct_chat_btn")
                            ) {
                                Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Open Direct WhatsApp Chat (${targetContact.phone})")
                            }
                        }
                    }
                }
            } else {
                // FACEBOOK & INSTAGRAM REELS TAB
                item {
                    PosterPreviewCard(
                        templateIndex = socialState.templateIndex,
                        badgeText = "REELS & PROMO",
                        headline = socialState.headline,
                        offerDetails = socialState.reelHook,
                        footerCta = "POWERHOUSE GYM • JOIN NOW"
                    )
                }

                item {
                    TemplateSelectorRow(
                        selectedIndex = socialState.templateIndex,
                        onSelect = { idx -> onUpdateSocial { it.copy(templateIndex = idx) } }
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CarbonBorder, RoundedCornerShape(18.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AI REELS & SOCIAL GENERATOR",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = InstagramRose,
                                    fontWeight = FontWeight.Bold
                                )
                                Button(
                                    onClick = onGenerateAiSocial,
                                    enabled = !socialState.isGeneratingAi,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VoltLime,
                                        contentColor = ObsidianBg
                                    ),
                                    modifier = Modifier.height(48.dp).testTag("generate_ai_reels_btn")
                                ) {
                                    if (socialState.isGeneratingAi) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = ObsidianBg)
                                    } else {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Reels Kit", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (socialState.error != null) {
                                Text(
                                    text = socialState.error,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            OutlinedTextField(
                                value = socialState.themeInput,
                                onValueChange = { v -> onUpdateSocial { it.copy(themeInput = v) } },
                                label = { Text("Campaign Theme") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = socialState.offerInput,
                                onValueChange = { v -> onUpdateSocial { it.copy(offerInput = v) } },
                                label = { Text("Membership Offer") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = socialState.reelHook,
                                onValueChange = { v -> onUpdateSocial { it.copy(reelHook = v) } },
                                label = { Text("3-Second Reel Hook") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = socialState.caption,
                                onValueChange = { v -> onUpdateSocial { it.copy(caption = v) } },
                                label = { Text("Facebook / Instagram Caption") },
                                minLines = 3,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = socialState.hashtags,
                                onValueChange = { v -> onUpdateSocial { it.copy(hashtags = v) } },
                                label = { Text("Hashtags") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Surface(
                                color = CarbonSurfaceHigh,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "REELS FILMING SHOT LIST",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = VoltLime,
                                            fontWeight = FontWeight.Bold
                                        )
                                        OutlinedButton(
                                            onClick = {
                                                PosterRendererAndShareHelper.copyToClipboard(
                                                    context,
                                                    "Reels Caption",
                                                    "${socialState.caption}\n\n${socialState.hashtags}"
                                                )
                                            },
                                            modifier = Modifier.height(48.dp)
                                        ) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy caption", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Copy Text")
                                        }
                                    }
                                    Text(
                                        text = socialState.shotList,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            // Optional Zero-Permission Video Picker for Reels
                            OutlinedButton(
                                onClick = {
                                    videoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pick_reel_video_btn")
                            ) {
                                Icon(Icons.Filled.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (socialState.selectedVideoUri != null) {
                                        "Reel Video Selected (Tap to Change)"
                                    } else {
                                        "Attach Gym Video Clip for Reel (Optional)"
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    val fullCaption = "${socialState.caption}\n\n${socialState.hashtags}"
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val videoUri = socialState.selectedVideoUri
                                val mediaUri = videoUri ?: run {
                                    val bmp = PosterRendererAndShareHelper.renderPosterBitmap(
                                        context = context,
                                        templateIndex = socialState.templateIndex,
                                        headline = socialState.headline,
                                        badgeText = "POWERHOUSE REEL",
                                        offerDetails = socialState.reelHook,
                                        clubContact = "CLAIM YOUR 7-DAY FREE TRIAL"
                                    )
                                    val u = PosterRendererAndShareHelper.savePosterToCacheUri(context, bmp)
                                    bmp.recycle()
                                    u
                                }
                                PosterRendererAndShareHelper.shareToInstagramReelOrPost(
                                    context = context,
                                    mediaUri = mediaUri,
                                    isVideo = videoUri != null,
                                    fullCaption = fullCaption
                                )
                                onRecordSocialShare(PromoPlatform.INSTAGRAM_REEL)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = InstagramRose,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("share_instagram_reel_btn")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Share Promotion Reel on Instagram", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val videoUri = socialState.selectedVideoUri
                                val mediaUri = videoUri ?: run {
                                    val bmp = PosterRendererAndShareHelper.renderPosterBitmap(
                                        context = context,
                                        templateIndex = socialState.templateIndex,
                                        headline = socialState.headline,
                                        badgeText = "POWERHOUSE GYM",
                                        offerDetails = socialState.offerInput,
                                        clubContact = "MESSAGE US FOR YOUR VIP PASS"
                                    )
                                    val u = PosterRendererAndShareHelper.savePosterToCacheUri(context, bmp)
                                    bmp.recycle()
                                    u
                                }
                                PosterRendererAndShareHelper.shareToFacebook(
                                    context = context,
                                    mediaUri = mediaUri,
                                    isVideo = videoUri != null,
                                    fullCaption = fullCaption
                                )
                                onRecordSocialShare(PromoPlatform.FACEBOOK)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FacebookBlue,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("share_facebook_post_btn")
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Share Promotion Post on Facebook", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PosterPreviewCard(
    templateIndex: Int,
    badgeText: String,
    headline: String,
    offerDetails: String,
    footerCta: String
) {
    val drawableRes = PosterTemplates.drawables[templateIndex.coerceIn(0, PosterTemplates.drawables.lastIndex)]
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CarbonBorder, RoundedCornerShape(20.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
        ) {
            Image(
                painter = painterResource(id = drawableRes),
                contentDescription = "PowerHouse Gym promotional poster background",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBg.copy(alpha = 0.72f),
                                Color.Transparent,
                                ObsidianBg.copy(alpha = 0.92f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "POWERHOUSE GYM",
                        style = MaterialTheme.typography.titleMedium,
                        color = VoltLime,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = VoltLime,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = badgeText.ifBlank { "VIP OFFER" }.uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = ObsidianBg,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = headline.ifBlank { "UNLEASH YOUR POWER" }.uppercase(),
                        style = MaterialTheme.typography.displayLarge,
                        color = Color.White,
                        maxLines = 3
                    )
                    Text(
                        text = offerDetails,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFD6DCE6),
                        maxLines = 3
                    )
                    Surface(
                        color = CarbonSurface.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, VoltLime, RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Campaign, contentDescription = null, tint = VoltLime, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = footerCta,
                                style = MaterialTheme.typography.labelLarge,
                                color = VoltLime,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TemplateSelectorRow(
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PosterTemplates.titles.forEachIndexed { index, title ->
            val selected = index == selectedIndex
            Surface(
                color = if (selected) VoltLime.copy(alpha = 0.18f) else CarbonSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .border(
                        1.dp,
                        if (selected) VoltLime else CarbonBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelect(index) }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selected) VoltLime else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
