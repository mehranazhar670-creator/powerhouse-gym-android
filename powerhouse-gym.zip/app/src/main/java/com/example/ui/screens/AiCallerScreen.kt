package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.PhoneForwarded
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CallOutcome
import com.example.data.model.DailyQuota
import com.example.data.model.GymContact
import com.example.data.repository.GymRepository
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceHigh
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PowerOrange
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.AiCallUiState
import com.example.util.PosterRendererAndShareHelper
import com.example.util.VoiceCoachManager

@Composable
fun AiCallerScreen(
    contacts: List<GymContact>,
    dailyQuota: DailyQuota,
    aiCallState: AiCallUiState,
    todayKey: String,
    onSelectContact: (GymContact) -> Unit,
    onSelectOffer: (String) -> Unit,
    onStartAiCall: (GymContact) -> Unit,
    onAskObjection: (String) -> Unit,
    onLogOutcome: (String) -> Unit,
    onNavigateToContacts: () -> Unit
) {
    val context = LocalContext.current
    val voiceCoach = remember { VoiceCoachManager(context) }
    val isSpeaking by voiceCoach.isSpeaking.collectAsStateWithLifecycle()
    val isTtsReady by voiceCoach.isReady.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            voiceCoach.shutdown()
        }
    }

    // Automatically speak AI generated script when ready
    LaunchedEffect(aiCallState.script) {
        val script = aiCallState.script
        if (script != null && isTtsReady) {
            voiceCoach.speak(script.fullSpokenScript())
        }
    }

    // Automatically speak live objection reply when generated
    LaunchedEffect(aiCallState.liveReply) {
        val reply = aiCallState.liveReply
        if (!reply.isNullOrBlank() && isTtsReady) {
            voiceCoach.speak(reply)
        }
    }

    val callsUsed = dailyQuota.callsAttended.toInt().coerceIn(0, GymRepository.MAX_DAILY_INVITATION_CALLS)
    val limitReached = callsUsed >= GymRepository.MAX_DAILY_INVITATION_CALLS
    val offers = listOf(
        "Free 7-Day VIP Pass + Body Assessment",
        "40% Off First 3 Months + Zero Joining Fee",
        "Free Personal Trainer Trial + Diet Plan"
    )
    var customQuestion by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "AI INVITATION CALLER",
                        style = MaterialTheme.typography.headlineLarge,
                        color = VoltLime
                    )
                    Text(
                        text = "Automated Gemini voice scripts • Daily cap of 2 attended invitation calls",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Daily 2-call quota bar
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (limitReached) PowerOrange.copy(alpha = 0.14f) else CarbonSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (limitReached) PowerOrange else CarbonBorder,
                            RoundedCornerShape(18.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Daily Invitation Quota ($todayKey)",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$callsUsed / ${GymRepository.MAX_DAILY_INVITATION_CALLS} Calls",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (limitReached) PowerOrange else VoltLime,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        LinearProgressIndicator(
                            progress = { callsUsed.toFloat() / GymRepository.MAX_DAILY_INVITATION_CALLS.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = if (limitReached) PowerOrange else VoltLime,
                            trackColor = CarbonSurfaceHigh,
                            strokeCap = StrokeCap.Round
                        )
                        if (limitReached) {
                            Text(
                                text = "Daily 2/2 invitation call limit reached. Come back tomorrow for your next 2 AI calls, or send WhatsApp posters anytime.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PowerOrange
                            )
                        }
                    }
                }
            }

            // Offer selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "INVITATION OFFER",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        offers.forEach { offer ->
                            FilterChip(
                                selected = aiCallState.selectedOffer == offer,
                                onClick = { onSelectOffer(offer) },
                                label = { Text(offer) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VoltLime,
                                    selectedLabelColor = ObsidianBg
                                )
                            )
                        }
                    }
                }
            }

            // Active AI Call Console
            val activeContact = aiCallState.selectedContact
            if (activeContact != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, VoltLime.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = activeContact.name,
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${activeContact.phone} • Goal: ${activeContact.goal}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                VoiceWaveformIndicator(isActive = isSpeaking || aiCallState.isGenerating)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onStartAiCall(activeContact) },
                                    enabled = !limitReached && !aiCallState.isGenerating,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VoltLime,
                                        contentColor = ObsidianBg
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("start_ai_call_button")
                                ) {
                                    if (aiCallState.isGenerating) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            color = ObsidianBg,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Preparing AI...")
                                    } else {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (limitReached) "2/2 Limit Reached" else "Auto AI Call",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        PosterRendererAndShareHelper.dialPhoneNumber(context, activeContact.phone)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("dial_phone_button")
                                ) {
                                    Icon(Icons.Filled.PhoneForwarded, contentDescription = "Open phone dialer", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Dial")
                                }
                            }

                            if (aiCallState.error != null) {
                                Text(
                                    text = aiCallState.error,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            if (aiCallState.statusBanner != null) {
                                Surface(
                                    color = VoltLime.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = aiCallState.statusBanner,
                                        color = VoltLime,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            val script = aiCallState.script
                            if (script != null) {
                                Surface(
                                    color = CarbonSurfaceHigh,
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "AI VOICE SCRIPT",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = VoltLime,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Button(
                                                onClick = {
                                                    if (isSpeaking) voiceCoach.stop() else voiceCoach.speak(script.fullSpokenScript())
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isSpeaking) PowerOrange else VoltLime.copy(alpha = 0.2f),
                                                    contentColor = if (isSpeaking) Color.White else VoltLime
                                                ),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                                modifier = Modifier.height(48.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isSpeaking) Icons.Filled.Stop else Icons.Filled.VolumeUp,
                                                    contentDescription = if (isSpeaking) "Stop voice" else "Speak script",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(if (isSpeaking) "Stop" else "Speak AI")
                                            }
                                        }
                                        Text(
                                            text = script.fullSpokenScript(),
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Objection Backup: ${script.objectionReply}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // Live Client Question / Objection Handler
                                Text(
                                    text = "LIVE PROSPECT Q&A (AI SPEAKS REPLY)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(
                                        "What is the monthly fee?",
                                        "What are your gym timings?",
                                        "Are trainers included?"
                                    ).forEach { q ->
                                        FilterChip(
                                            selected = false,
                                            onClick = { onAskObjection(q) },
                                            label = { Text(q) }
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = customQuestion,
                                        onValueChange = { customQuestion = it },
                                        label = { Text("Client asked...") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = {
                                            if (customQuestion.isNotBlank()) {
                                                onAskObjection(customQuestion)
                                                customQuestion = ""
                                            }
                                        },
                                        enabled = !aiCallState.isGeneratingReply && customQuestion.isNotBlank(),
                                        modifier = Modifier.height(52.dp)
                                    ) {
                                        Icon(Icons.Filled.RecordVoiceOver, contentDescription = "Answer with AI")
                                    }
                                }

                                if (aiCallState.liveReply != null) {
                                    Surface(
                                        color = VoltLime.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "AI Reply: ${aiCallState.liveReply}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = VoltLime,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                }

                                // Log Daily Attended Call Outcome (Counts towards 2/2 daily limit)
                                Text(
                                    text = "LOG DAILY INVITATION RESULT (COUNTS TOWARD 2/DAY)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutcomeButton(
                                        label = "Attended",
                                        color = VoltLime,
                                        textColor = ObsidianBg,
                                        enabled = !limitReached && !aiCallState.isLoggingCall,
                                        modifier = Modifier.weight(1f).testTag("log_attended_btn"),
                                        onClick = { onLogOutcome(CallOutcome.ATTENDED) }
                                    )
                                    OutcomeButton(
                                        label = "Interested",
                                        color = Color(0xFF25D366),
                                        textColor = ObsidianBg,
                                        enabled = !limitReached && !aiCallState.isLoggingCall,
                                        modifier = Modifier.weight(1f).testTag("log_interested_btn"),
                                        onClick = { onLogOutcome(CallOutcome.INTERESTED) }
                                    )
                                    OutcomeButton(
                                        label = "No Answer",
                                        color = CarbonSurfaceHigh,
                                        textColor = Color.White,
                                        enabled = !limitReached && !aiCallState.isLoggingCall,
                                        modifier = Modifier.weight(1f).testTag("log_no_answer_btn"),
                                        onClick = { onLogOutcome(CallOutcome.NO_ANSWER) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Queue of Leads to Invite
            item {
                Text(
                    text = "SELECT CLIENT FOR AI INVITATION CALL",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (contacts.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CarbonBorder, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Your contact list is empty. Add up to 1,000 prospects to start AI invitation calling.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = onNavigateToContacts,
                                colors = ButtonDefaults.buttonColors(containerColor = VoltLime, contentColor = ObsidianBg),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("Add Contacts Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(contacts.take(30), key = { it.id }) { contact ->
                    val isSelected = aiCallState.selectedContact?.id == contact.id
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) VoltLime.copy(alpha = 0.12f) else CarbonSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (isSelected) VoltLime else CarbonBorder,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelectContact(contact) }
                            .testTag("caller_contact_${contact.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${contact.phone} • ${contact.goal}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                color = CarbonSurfaceHigh,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (contact.lastCalledDate == todayKey) "Called Today" else "Ready",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (contact.lastCalledDate == todayKey) PowerOrange else VoltLime,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OutcomeButton(
    label: String,
    color: Color,
    textColor: Color,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = textColor),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        modifier = modifier.height(48.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun VoiceWaveformIndicator(isActive: Boolean) {
    val transition = rememberInfiniteTransition(label = "wave")
    val pulse by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(420),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(CarbonSurfaceHigh)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Call,
            contentDescription = null,
            tint = if (isActive) VoltLime else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
        )
        listOf(10, 18, 14, 20, 12).forEachIndexed { idx, baseH ->
            val factor = if (isActive) (if (idx % 2 == 0) pulse else 1.35f - pulse) else 0.4f
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((baseH * factor).dp)
                    .clip(CircleShape)
                    .background(if (isActive) VoltLime else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
            )
        }
    }
}
