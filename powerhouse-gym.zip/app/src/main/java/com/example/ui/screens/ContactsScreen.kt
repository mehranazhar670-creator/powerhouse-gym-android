package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ContactStatus
import com.example.data.model.GymContact
import com.example.data.model.GymGoals
import com.example.data.repository.GymRepository
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceHigh
import com.example.ui.theme.CyanPulse
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PowerOrange
import com.example.ui.theme.VoltLime
import com.example.ui.theme.WhatsAppGreen

@Composable
fun ContactsScreen(
    contacts: List<GymContact>,
    onAddContact: (name: String, phone: String, goal: String, notes: String) -> Unit,
    onBulkImportText: (rawText: String, defaultGoal: String) -> Unit,
    onUpdateMember: (id: String, name: String, phone: String, goal: String, status: String, notes: String) -> Unit,
    onUpdateMemberStatus: (GymContact, String) -> Unit,
    onDeleteContact: (String) -> Unit,
    onQuickAiCall: (GymContact) -> Unit,
    onQuickWhatsAppPoster: (GymContact) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }
    var showBulkDialog by remember { mutableStateOf(false) }
    var editingMember by remember { mutableStateOf<GymContact?>(null) }

    val fileImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val content = context.contentResolver.openInputStream(uri)
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    .orEmpty()
                if (content.isNotBlank()) {
                    onBulkImportText(content, "General Fitness")
                }
            } catch (_: Exception) {
                // Handled gracefully
            }
        }
    }

    val filteredContacts = remember(contacts, searchQuery, selectedFilter) {
        contacts.filter { c ->
            val matchesQuery = searchQuery.isBlank() ||
                c.name.contains(searchQuery, ignoreCase = true) ||
                c.phone.contains(searchQuery, ignoreCase = true) ||
                c.goal.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "New" -> c.status == ContactStatus.NEW
                "Invited" -> c.status == ContactStatus.INVITED
                "Interested" -> c.status == ContactStatus.INTERESTED
                "Joined" -> c.status == ContactStatus.JOINED
                "Declined" -> c.status == ContactStatus.NOT_INTERESTED
                "Poster Sent" -> c.posterSent
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    val atCapacity = contacts.size >= GymRepository.MAX_CONTACTS

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MEMBER MANAGEMENT",
                                style = MaterialTheme.typography.headlineLarge,
                                color = VoltLime
                            )
                            Text(
                                text = "Firestore Lead Directory • Name, Phone & Invitation Status",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${contacts.size} / ${GymRepository.MAX_CONTACTS}",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (atCapacity) PowerOrange else VoltLime,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (contacts.size.toFloat() / GymRepository.MAX_CONTACTS.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (atCapacity) PowerOrange else VoltLime,
                        trackColor = CarbonSurfaceHigh,
                        strokeCap = StrokeCap.Round
                    )
                }
            }

            // Invitation Pipeline Breakdown Strip
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CarbonBorder, RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusMetric("New", contacts.count { it.status == ContactStatus.NEW }, CyanPulse)
                        StatusMetric("Invited", contacts.count { it.status == ContactStatus.INVITED }, PowerOrange)
                        StatusMetric("Interested", contacts.count { it.status == ContactStatus.INTERESTED }, VoltLime)
                        StatusMetric("Joined", contacts.count { it.status == ContactStatus.JOINED }, WhatsAppGreen)
                    }
                }
            }

            // Action Buttons Row: Add Member, Bulk Paste, Import File
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddDialog = true },
                        enabled = !atCapacity,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VoltLime,
                            contentColor = ObsidianBg
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("add_contact_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Lead", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showBulkDialog = true },
                        enabled = !atCapacity,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("bulk_paste_button")
                    ) {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bulk")
                    }

                    OutlinedButton(
                        onClick = {
                            fileImportLauncher.launch(arrayOf("text/*", "text/csv", "text/vcard", "text/x-vcard"))
                        },
                        enabled = !atCapacity,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("import_csv_button")
                    ) {
                        Icon(Icons.Filled.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CSV/VCF")
                    }
                }
            }

            // Search + Invitation Status Filter Chips
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        placeholder = { Text("Search member name, phone, or goal...") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("contacts_search_input")
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("All", "New", "Invited", "Interested", "Joined", "Declined", "Poster Sent").forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VoltLime,
                                    selectedLabelColor = ObsidianBg
                                )
                            )
                        }
                    }
                }
            }

            if (filteredContacts.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CarbonBorder, RoundedCornerShape(16.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (contacts.isEmpty()) "No Leads Added Yet" else "No Matching Leads",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Store up to 1,000 potential gym leads in Firestore with names, phone numbers, and invitation statuses.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredContacts, key = { it.id }) { contact ->
                    MemberLeadCard(
                        contact = contact,
                        onEdit = { editingMember = contact },
                        onStatusChanged = { newStatus -> onUpdateMemberStatus(contact, newStatus) },
                        onCall = { onQuickAiCall(contact) },
                        onSendPoster = { onQuickWhatsAppPoster(contact) },
                        onDelete = { onDeleteContact(contact.id) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddSingleContactDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, phone, goal, notes ->
                onAddContact(name, phone, goal, notes)
                showAddDialog = false
            }
        )
    }

    if (showBulkDialog) {
        BulkPasteContactsDialog(
            remainingSlots = (GymRepository.MAX_CONTACTS - contacts.size).coerceAtLeast(0),
            onDismiss = { showBulkDialog = false },
            onImport = { raw, goal ->
                onBulkImportText(raw, goal)
                showBulkDialog = false
            }
        )
    }

    editingMember?.let { member ->
        EditMemberDialog(
            member = member,
            onDismiss = { editingMember = null },
            onSave = { name, phone, goal, status, notes ->
                onUpdateMember(member.id, name, phone, goal, status, notes)
                editingMember = null
            }
        )
    }
}

@Composable
private fun StatusMetric(label: String, count: Int, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.titleLarge,
            color = accent,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MemberLeadCard(
    contact: GymContact,
    onEdit: () -> Unit,
    onStatusChanged: (String) -> Unit,
    onCall: () -> Unit,
    onSendPoster: () -> Unit,
    onDelete: () -> Unit
) {
    var statusMenuExpanded by remember { mutableStateOf(false) }
    val statusColor = when (contact.status) {
        ContactStatus.JOINED -> WhatsAppGreen
        ContactStatus.INTERESTED -> VoltLime
        ContactStatus.INVITED -> PowerOrange
        ContactStatus.NOT_INTERESTED -> MaterialTheme.colorScheme.error
        else -> CyanPulse
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CarbonBorder, RoundedCornerShape(16.dp))
            .clickable { onEdit() }
            .testTag("contact_card_${contact.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = contact.name.firstOrNull()?.uppercase() ?: "M",
                        style = MaterialTheme.typography.titleMedium,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = contact.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${contact.phone} • ${contact.goal}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(48.dp).testTag("edit_member_${contact.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = "Edit ${contact.name}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (contact.notes.isNotBlank()) {
                Text(
                    text = contact.notes,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box {
                        Surface(
                            color = statusColor.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                .clickable { statusMenuExpanded = true }
                                .testTag("member_status_pill_${contact.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ContactStatus.label(contact.status),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = statusColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(
                                    imageVector = Icons.Filled.ArrowDropDown,
                                    contentDescription = "Change invitation status",
                                    tint = statusColor,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = statusMenuExpanded,
                            onDismissRequest = { statusMenuExpanded = false }
                        ) {
                            ContactStatus.ALL.forEach { statusOption ->
                                DropdownMenuItem(
                                    text = { Text(ContactStatus.label(statusOption)) },
                                    onClick = {
                                        statusMenuExpanded = false
                                        onStatusChanged(statusOption)
                                    }
                                )
                            }
                        }
                    }

                    if (contact.posterSent) {
                        Surface(
                            color = WhatsAppGreen.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Poster Sent",
                                style = MaterialTheme.typography.labelSmall,
                                color = WhatsAppGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCall, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = "AI call ${contact.name}",
                            tint = VoltLime
                        )
                    }
                    IconButton(onClick = onSendPoster, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Campaign,
                            contentDescription = "Send WhatsApp poster to ${contact.name}",
                            tint = WhatsAppGreen
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete ${contact.name}",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddSingleContactDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedGoal by remember { mutableStateOf(GymGoals.ALL.first()) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Potential Lead") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_contact_name")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone (with country code, e.g. +1...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_contact_phone")
                )
                Text("Fitness Goal", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GymGoals.ALL.forEach { goal ->
                        FilterChip(
                            selected = selectedGoal == goal,
                            onClick = { selectedGoal = goal },
                            label = { Text(goal) }
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, phone, selectedGoal, notes) },
                enabled = name.isNotBlank() && phone.trim().length >= 5,
                modifier = Modifier.testTag("dialog_save_contact")
            ) {
                Text("Save Lead")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun EditMemberDialog(
    member: GymContact,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var name by remember(member.id) { mutableStateOf(member.name) }
    var phone by remember(member.id) { mutableStateOf(member.phone) }
    var selectedGoal by remember(member.id) { mutableStateOf(member.goal) }
    var selectedStatus by remember(member.id) { mutableStateOf(member.status) }
    var notes by remember(member.id) { mutableStateOf(member.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manage Member Lead") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_member_name")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_member_phone")
                )
                Text("Invitation Status", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ContactStatus.ALL.forEach { statusOption ->
                        FilterChip(
                            selected = selectedStatus == statusOption,
                            onClick = { selectedStatus = statusOption },
                            label = { Text(ContactStatus.label(statusOption)) }
                        )
                    }
                }
                Text("Fitness Goal", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GymGoals.ALL.forEach { goal ->
                        FilterChip(
                            selected = selectedGoal == goal,
                            onClick = { selectedGoal = goal },
                            label = { Text(goal) }
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_member_notes")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, phone, selectedGoal, selectedStatus, notes) },
                enabled = name.isNotBlank() && phone.trim().length >= 5,
                modifier = Modifier.testTag("edit_member_save")
            ) {
                Text("Update")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun BulkPasteContactsDialog(
    remainingSlots: Int,
    onDismiss: () -> Unit,
    onImport: (String, String) -> Unit
) {
    var rawText by remember { mutableStateOf("") }
    var selectedGoal by remember { mutableStateOf("General Fitness") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bulk Add Leads ($remainingSlots slots left)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Paste up to 1,000 lines formatted as: Name, +PhoneNumber",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    placeholder = { Text("Rahul Sharma, +919876543210\nPriya Patel, +919811223344") },
                    minLines = 5,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth().testTag("bulk_paste_input")
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GymGoals.ALL.forEach { goal ->
                        FilterChip(
                            selected = selectedGoal == goal,
                            onClick = { selectedGoal = goal },
                            label = { Text(goal) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onImport(rawText, selectedGoal) },
                enabled = rawText.isNotBlank() && remainingSlots > 0,
                modifier = Modifier.testTag("bulk_import_confirm")
            ) {
                Text("Import All")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
