package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.ai.GymAiService
import com.example.data.firebase.configureAppCheck
import com.example.data.repository.GymRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.screens.AiCallerScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PromoStudioScreen
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PowerHouseGymTheme
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.DataUiState
import com.example.ui.viewmodel.PowerHouseViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object Routes {
    const val DASHBOARD = "dashboard"
    const val CALLER = "caller"
    const val CONTACTS = "contacts"
    const val PROMO = "promo"
}

private data class NavDestinationItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory Step 1: Configure App Check with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            PowerHouseGymTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            PowerHouseMainContent(currentUserId = user.uid)
        }
    }
}

@Composable
fun PowerHouseMainContent(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: PowerHouseViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                PowerHouseViewModel(
                    repository = GymRepository(db),
                    aiService = GymAiService(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val contactsUiState by viewModel.contactsState.collectAsStateWithLifecycle()
    val dailyQuota by viewModel.dailyQuotaState.collectAsStateWithLifecycle()
    val callLogs by viewModel.callLogsState.collectAsStateWithLifecycle()
    val aiCallState by viewModel.aiCallState.collectAsStateWithLifecycle()
    val whatsAppState by viewModel.whatsAppState.collectAsStateWithLifecycle()
    val socialState by viewModel.socialState.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeFeedback()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Routes.DASHBOARD
    var promoTabIndex by rememberSaveable { mutableIntStateOf(0) }

    val navItems = listOf(
        NavDestinationItem(
            route = Routes.DASHBOARD,
            labelRes = R.string.nav_dashboard,
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_dashboard"
        ),
        NavDestinationItem(
            route = Routes.CALLER,
            labelRes = R.string.nav_caller,
            selectedIcon = Icons.Filled.Call,
            unselectedIcon = Icons.Outlined.Call,
            testTag = "nav_caller"
        ),
        NavDestinationItem(
            route = Routes.CONTACTS,
            labelRes = R.string.nav_contacts,
            selectedIcon = Icons.Filled.Contacts,
            unselectedIcon = Icons.Outlined.Contacts,
            testTag = "nav_contacts"
        ),
        NavDestinationItem(
            route = Routes.PROMO,
            labelRes = R.string.nav_promo,
            selectedIcon = Icons.Filled.Campaign,
            unselectedIcon = Icons.Outlined.Campaign,
            testTag = "nav_promo"
        )
    )

    val navigateToRoute: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(Routes.DASHBOARD) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    val contactsList = when (val state = contactsUiState) {
        is DataUiState.Success -> state.data
        else -> emptyList()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            containerColor = ObsidianBg,
            contentWindowInsets = WindowInsets.navigationBars,
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = CarbonSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToRoute(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(id = item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(id = item.labelRes)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBg,
                                    selectedTextColor = VoltLime,
                                    indicatorColor = VoltLime,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(containerColor = CarbonSurface) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToRoute(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(id = item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(id = item.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ObsidianBg,
                                    selectedTextColor = VoltLime,
                                    indicatorColor = VoltLime
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    if (contactsUiState is DataUiState.Loading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = VoltLime)
                        }
                    } else {
                        NavHost(
                            navController = navController,
                            startDestination = Routes.DASHBOARD
                        ) {
                            composable(Routes.DASHBOARD) {
                                DashboardScreen(
                                    contacts = contactsList,
                                    dailyQuota = dailyQuota,
                                    callLogs = callLogs,
                                    onNavigateToCaller = { navigateToRoute(Routes.CALLER) },
                                    onNavigateToContacts = { navigateToRoute(Routes.CONTACTS) },
                                    onNavigateToWhatsAppPromo = {
                                        promoTabIndex = 0
                                        navigateToRoute(Routes.PROMO)
                                    },
                                    onNavigateToReelsPromo = {
                                        promoTabIndex = 1
                                        navigateToRoute(Routes.PROMO)
                                    },
                                    onSignOut = {
                                        signOutUser(credentialManager, scope)
                                    }
                                )
                            }

                            composable(Routes.CALLER) {
                                AiCallerScreen(
                                    contacts = contactsList,
                                    dailyQuota = dailyQuota,
                                    aiCallState = aiCallState,
                                    todayKey = viewModel.todayKey,
                                    onSelectContact = { viewModel.selectContactForAiCall(it) },
                                    onSelectOffer = { viewModel.updateCallOffer(it) },
                                    onStartAiCall = { viewModel.generateAiInvitationCall(it) },
                                    onAskObjection = { viewModel.askLiveObjectionReply(it) },
                                    onLogOutcome = { viewModel.logAiCallOutcome(it) },
                                    onNavigateToContacts = { navigateToRoute(Routes.CONTACTS) }
                                )
                            }

                            composable(Routes.CONTACTS) {
                                ContactsScreen(
                                    contacts = contactsList,
                                    onAddContact = { name, phone, goal, notes ->
                                        viewModel.addSingleContact(name, phone, goal, notes)
                                    },
                                    onBulkImportText = { raw, goal ->
                                        viewModel.importContactsFromText(raw, goal)
                                    },
                                    onUpdateMember = { id, name, phone, goal, status, notes ->
                                        viewModel.updateMemberLead(id, name, phone, goal, status, notes)
                                    },
                                    onUpdateMemberStatus = { contact, newStatus ->
                                        viewModel.quickUpdateInvitationStatus(contact, newStatus)
                                    },
                                    onDeleteContact = { viewModel.deleteContact(it) },
                                    onQuickAiCall = { contact ->
                                        viewModel.selectContactForAiCall(contact)
                                        navigateToRoute(Routes.CALLER)
                                    },
                                    onQuickWhatsAppPoster = { contact ->
                                        viewModel.updateWhatsAppStudio { it.copy(targetContactId = contact.id) }
                                        promoTabIndex = 0
                                        navigateToRoute(Routes.PROMO)
                                    }
                                )
                            }

                            composable(Routes.PROMO) {
                                PromoStudioScreen(
                                    selectedTabIndex = promoTabIndex,
                                    onSelectTab = { promoTabIndex = it },
                                    contacts = contactsList,
                                    whatsAppState = whatsAppState,
                                    socialState = socialState,
                                    onUpdateWhatsApp = { viewModel.updateWhatsAppStudio(it) },
                                    onGenerateAiWhatsApp = { offer, name ->
                                        viewModel.generateAiWhatsAppCopy(offer, name)
                                    },
                                    onRecordWhatsAppSent = { contactId ->
                                        viewModel.markWhatsAppPosterDispatched(contactId)
                                    },
                                    onUpdateSocial = { viewModel.updateSocialStudio(it) },
                                    onGenerateAiSocial = { viewModel.generateAiSocialKit() },
                                    onRecordSocialShare = { platform ->
                                        viewModel.recordSocialShare(platform)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
