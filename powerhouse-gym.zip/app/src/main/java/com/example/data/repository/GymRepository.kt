package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.CallLog
import com.example.data.model.CallOutcome
import com.example.data.model.ContactStatus
import com.example.data.model.DailyQuota
import com.example.data.model.GymContact
import com.example.data.model.GymGoals
import com.example.data.model.PromoCampaign
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GymRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    companion object {
        const val MAX_CONTACTS = 1000
        const val MAX_DAILY_INVITATION_CALLS = 2

        fun todayDateKey(): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        }
    }

    private fun contactsRef(userId: String) =
        db.collection("users").document(userId).collection("contacts")

    private fun dailyQuotasRef(userId: String) =
        db.collection("users").document(userId).collection("daily_quotas")

    private fun callLogsRef(userId: String) =
        db.collection("users").document(userId).collection("call_logs")

    private fun promoCampaignsRef(userId: String) =
        db.collection("users").document(userId).collection("promo_campaigns")

    fun observeContacts(userId: String): Flow<List<GymContact>> {
        val path = "users/$userId/contacts"
        return contactsRef(userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GymContact::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeDailyQuota(userId: String, dateKey: String): Flow<DailyQuota> {
        val path = "users/$userId/daily_quotas/$dateKey"
        return dailyQuotasRef(userId).document(dateKey)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        DailyQuota::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: DailyQuota(id = dateKey, userId = userId, dateKey = dateKey)
                } else {
                    DailyQuota(id = dateKey, userId = userId, dateKey = dateKey)
                }
            }
            .catch { error ->
                handleFirestoreError(error, OperationType.GET, path)
                throw error
            }
    }

    fun observeCallLogs(userId: String): Flow<List<CallLog>> {
        val path = "users/$userId/call_logs"
        return callLogsRef(userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    CallLog::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observePromoCampaigns(userId: String): Flow<List<PromoCampaign>> {
        val path = "users/$userId/promo_campaigns"
        return promoCampaignsRef(userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(30)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    PromoCampaign::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun getContacts(userId: String): Result<List<GymContact>> {
        val path = "users/$userId/contacts"
        return try {
            val snap = contactsRef(userId).get().await()
            Result.success(
                snap.toObjects(
                    GymContact::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun addContact(
        userId: String,
        name: String,
        phone: String,
        goal: String,
        notes: String = ""
    ): Result<String> {
        val cleanName = name.trim().take(100)
        val cleanPhone = phone.trim().take(25)
        if (cleanName.isBlank()) {
            return Result.failure(IllegalArgumentException("Contact name is required."))
        }
        if (cleanPhone.length < 5) {
            return Result.failure(IllegalArgumentException("Phone number must be at least 5 characters."))
        }
        val validGoal = if (goal in GymGoals.ALL) goal else "General Fitness"
        val docRef = contactsRef(userId).document()
        return try {
            val existingCount = contactsRef(userId).get().await().size()
            if (existingCount >= MAX_CONTACTS) {
                return Result.failure(
                    IllegalStateException("Contact limit of $MAX_CONTACTS contacts reached.")
                )
            }
            val payload = mapOf(
                "userId" to userId,
                "name" to cleanName,
                "phone" to cleanPhone,
                "goal" to validGoal,
                "status" to ContactStatus.NEW,
                "callsTodayCount" to 0L,
                "totalCallsCount" to 0L,
                "lastCalledDate" to "",
                "posterSent" to false,
                "notes" to notes.trim().take(500),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun importContactsBulk(
        userId: String,
        entries: List<Pair<String, String>>,
        defaultGoal: String = "General Fitness"
    ): Result<Int> {
        val validGoal = if (defaultGoal in GymGoals.ALL) defaultGoal else "General Fitness"
        val path = "users/$userId/contacts"
        return try {
            val currentSnap = contactsRef(userId).get().await()
            val remainingSlots = (MAX_CONTACTS - currentSnap.size()).coerceAtLeast(0)
            if (remainingSlots == 0) {
                return Result.failure(
                    IllegalStateException("Maximum capacity of $MAX_CONTACTS contacts reached.")
                )
            }

            val cleaned = entries
                .map { (n, p) -> n.trim().take(100) to p.trim().take(25) }
                .filter { (n, p) -> n.isNotBlank() && p.length >= 5 }
                .take(remainingSlots)

            if (cleaned.isEmpty()) {
                return Result.failure(
                    IllegalArgumentException("No valid contacts found. Format each line as: Name, +Phone")
                )
            }

            var totalWritten = 0
            cleaned.chunked(400).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { (name, phone) ->
                    val ref = contactsRef(userId).document()
                    batch.set(
                        ref,
                        mapOf(
                            "userId" to userId,
                            "name" to name,
                            "phone" to phone,
                            "goal" to validGoal,
                            "status" to ContactStatus.NEW,
                            "callsTodayCount" to 0L,
                            "totalCallsCount" to 0L,
                            "lastCalledDate" to "",
                            "posterSent" to false,
                            "notes" to "Imported lead",
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch.commit().await()
                totalWritten += chunk.size
            }
            Result.success(totalWritten)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateContactStatus(
        userId: String,
        contact: GymContact,
        newStatus: String,
        notes: String = contact.notes
    ): Result<Unit> {
        if (contact.id.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing contact ID"))
        }
        val docRef = contactsRef(userId).document(contact.id)
        return try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "notes" to notes.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateMemberLead(
        userId: String,
        contactId: String,
        name: String,
        phone: String,
        goal: String,
        status: String,
        notes: String
    ): Result<Unit> {
        val cleanName = name.trim().take(100)
        val cleanPhone = phone.trim().take(25)
        if (contactId.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing member ID."))
        }
        if (cleanName.isBlank()) {
            return Result.failure(IllegalArgumentException("Member name is required."))
        }
        if (cleanPhone.length < 5) {
            return Result.failure(IllegalArgumentException("Phone number must be at least 5 characters."))
        }
        val validGoal = if (goal in GymGoals.ALL) goal else "General Fitness"
        val validStatus = if (status in ContactStatus.ALL) status else ContactStatus.NEW
        val docRef = contactsRef(userId).document(contactId)
        return try {
            docRef.update(
                mapOf(
                    "name" to cleanName,
                    "phone" to cleanPhone,
                    "goal" to validGoal,
                    "status" to validStatus,
                    "notes" to notes.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteContact(userId: String, contactId: String): Result<Unit> {
        val docRef = contactsRef(userId).document(contactId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun recordInvitationCall(
        userId: String,
        contact: GymContact,
        dateKey: String,
        outcome: String,
        aiScriptSummary: String,
        durationSeconds: Int
    ): Result<Unit> {
        if (contact.id.isBlank()) {
            return Result.failure(IllegalArgumentException("Contact ID is required."))
        }
        val quotaRef = dailyQuotasRef(userId).document(dateKey)
        val contactRef = contactsRef(userId).document(contact.id)
        val logRef = callLogsRef(userId).document()

        return try {
            db.runTransaction { transaction ->
                val quotaSnap = transaction.get(quotaRef)
                val contactSnap = transaction.get(contactRef)
                val currentCallsAttended = if (quotaSnap.exists()) {
                    (quotaSnap.getLong("callsAttended") ?: 0L)
                } else {
                    0L
                }

                if (currentCallsAttended >= MAX_DAILY_INVITATION_CALLS) {
                    throw IllegalStateException(
                        "Daily limit of $MAX_DAILY_INVITATION_CALLS invitation calls attended reached for $dateKey."
                    )
                }

                val existingLastDate = contactSnap.getString("lastCalledDate") ?: ""
                val existingCallsToday = contactSnap.getLong("callsTodayCount") ?: 0L
                val existingTotalCalls = contactSnap.getLong("totalCallsCount") ?: 0L

                val nextCallsToday = if (existingLastDate == dateKey) {
                    (existingCallsToday + 1L).coerceAtMost(MAX_DAILY_INVITATION_CALLS.toLong())
                } else {
                    1L
                }

                val nextStatus = when (outcome) {
                    CallOutcome.INTERESTED -> ContactStatus.INTERESTED
                    CallOutcome.DECLINED -> ContactStatus.NOT_INTERESTED
                    else -> ContactStatus.INVITED
                }

                if (quotaSnap.exists()) {
                    transaction.update(
                        quotaRef,
                        mapOf(
                            "callsAttended" to currentCallsAttended + 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    transaction.set(
                        quotaRef,
                        mapOf(
                            "userId" to userId,
                            "dateKey" to dateKey,
                            "callsAttended" to 1L,
                            "postersSent" to 0L,
                            "reelsShared" to 0L,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                transaction.update(
                    contactRef,
                    mapOf(
                        "callsTodayCount" to nextCallsToday,
                        "totalCallsCount" to existingTotalCalls + 1L,
                        "lastCalledDate" to dateKey,
                        "status" to nextStatus,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                transaction.set(
                    logRef,
                    mapOf(
                        "userId" to userId,
                        "contactId" to contact.id,
                        "contactName" to contact.name.take(100),
                        "contactPhone" to contact.phone.take(25),
                        "dateKey" to dateKey,
                        "outcome" to outcome,
                        "aiScriptSummary" to aiScriptSummary.take(1000),
                        "durationSeconds" to durationSeconds.coerceIn(0, 3600).toLong(),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, quotaRef.path)
            Result.failure(e)
        }
    }

    suspend fun markPosterSent(
        userId: String,
        contactId: String?,
        dateKey: String
    ): Result<Unit> {
        val quotaRef = dailyQuotasRef(userId).document(dateKey)
        return try {
            db.runTransaction { transaction ->
                val quotaSnap = transaction.get(quotaRef)
                if (quotaSnap.exists()) {
                    val currentPosters = quotaSnap.getLong("postersSent") ?: 0L
                    transaction.update(
                        quotaRef,
                        mapOf(
                            "postersSent" to currentPosters + 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    transaction.set(
                        quotaRef,
                        mapOf(
                            "userId" to userId,
                            "dateKey" to dateKey,
                            "callsAttended" to 0L,
                            "postersSent" to 1L,
                            "reelsShared" to 0L,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                if (!contactId.isNullOrBlank()) {
                    val contactRef = contactsRef(userId).document(contactId)
                    transaction.update(
                        contactRef,
                        mapOf(
                            "posterSent" to true,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, quotaRef.path)
            Result.failure(e)
        }
    }

    suspend fun saveAndTrackPromoShare(
        userId: String,
        platform: String,
        headline: String,
        caption: String,
        reelHook: String,
        hashtags: String,
        templateIndex: Int,
        dateKey: String
    ): Result<String> {
        val campaignRef = promoCampaignsRef(userId).document()
        val quotaRef = dailyQuotasRef(userId).document(dateKey)
        return try {
            db.runTransaction { transaction ->
                val quotaSnap = transaction.get(quotaRef)
                if (quotaSnap.exists()) {
                    val currentReels = quotaSnap.getLong("reelsShared") ?: 0L
                    transaction.update(
                        quotaRef,
                        mapOf(
                            "reelsShared" to currentReels + 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    transaction.set(
                        quotaRef,
                        mapOf(
                            "userId" to userId,
                            "dateKey" to dateKey,
                            "callsAttended" to 0L,
                            "postersSent" to 0L,
                            "reelsShared" to 1L,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                transaction.set(
                    campaignRef,
                    mapOf(
                        "userId" to userId,
                        "platform" to platform,
                        "headline" to headline.trim().ifBlank { "PowerHouse Gym VIP Offer" }.take(120),
                        "caption" to caption.trim().ifBlank { "Join PowerHouse Gym today!" }.take(2500),
                        "reelHook" to reelHook.trim().take(500),
                        "hashtags" to hashtags.trim().take(500),
                        "templateIndex" to templateIndex.coerceIn(0, 2).toLong(),
                        "sharedCount" to 1L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(campaignRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, campaignRef.path)
            Result.failure(e)
        }
    }
}
