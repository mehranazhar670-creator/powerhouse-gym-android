package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

object GymGoals {
    val ALL = listOf(
        "Strength",
        "Weight Loss",
        "Cardio & HIIT",
        "Personal Training",
        "General Fitness"
    )
}

object ContactStatus {
    const val NEW = "new"
    const val INVITED = "invited"
    const val INTERESTED = "interested"
    const val JOINED = "joined"
    const val NOT_INTERESTED = "not_interested"

    val ALL = listOf(NEW, INVITED, INTERESTED, JOINED, NOT_INTERESTED)

    fun label(status: String): String = when (status) {
        NEW -> "New Lead"
        INVITED -> "Invited"
        INTERESTED -> "Interested"
        JOINED -> "Joined"
        NOT_INTERESTED -> "Declined"
        else -> "New Lead"
    }
}

object CallOutcome {
    const val ATTENDED = "attended"
    const val INTERESTED = "interested"
    const val NO_ANSWER = "no_answer"
    const val DECLINED = "declined"

    fun label(outcome: String): String = when (outcome) {
        ATTENDED -> "Attended"
        INTERESTED -> "Interested"
        NO_ANSWER -> "No Answer"
        DECLINED -> "Declined"
        else -> outcome
    }
}

object PromoPlatform {
    const val WHATSAPP = "whatsapp"
    const val INSTAGRAM_REEL = "instagram_reel"
    const val FACEBOOK = "facebook"
}

@IgnoreExtraProperties
data class GymContact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val goal: String = "Strength",
    val status: String = ContactStatus.NEW,
    val callsTodayCount: Long = 0L,
    val totalCallsCount: Long = 0L,
    val lastCalledDate: String = "",
    val posterSent: Boolean = false,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DailyQuota(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dateKey: String = "",
    val callsAttended: Long = 0L,
    val postersSent: Long = 0L,
    val reelsShared: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CallLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contactId: String = "",
    val contactName: String = "",
    val contactPhone: String = "",
    val dateKey: String = "",
    val outcome: String = CallOutcome.ATTENDED,
    val aiScriptSummary: String = "",
    val durationSeconds: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PromoCampaign(
    @DocumentId val id: String = "",
    val userId: String = "",
    val platform: String = PromoPlatform.INSTAGRAM_REEL,
    val headline: String = "",
    val caption: String = "",
    val reelHook: String = "",
    val hashtags: String = "",
    val templateIndex: Long = 0L,
    val sharedCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
