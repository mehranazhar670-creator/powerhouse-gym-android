package com.example.data.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class AiCallScript(
    val greeting: String,
    val pitch: String,
    val objectionReply: String,
    val closingCta: String,
    val summary: String
) {
    fun fullSpokenScript(): String =
        "$greeting $pitch $closingCta"
}

data class AiWhatsAppCopy(
    val posterHeadline: String,
    val badgeText: String,
    val whatsappMessage: String
)

data class AiSocialPromoKit(
    val headline: String,
    val reelHook: String,
    val shotList: String,
    val caption: String,
    val hashtags: String
)

class GymAiService {
    private val callScriptSchema = Schema.obj(
        properties = mapOf(
            "greeting" to Schema.string(description = "Warm personalized AI voice greeting using the prospect's name"),
            "pitch" to Schema.string(description = "2-sentence energetic invitation highlighting PowerHouse Gym's VIP trial and equipment"),
            "objectionReply" to Schema.string(description = "Short persuasive reply if they ask about timings or membership fees"),
            "closingCta" to Schema.string(description = "Clear call to action to claim their 7-day VIP guest pass today"),
            "summary" to Schema.string(description = "One-line summary for CRM call log")
        )
    )

    private val whatsappSchema = Schema.obj(
        properties = mapOf(
            "posterHeadline" to Schema.string(description = "Short bold 3-5 word gym poster headline"),
            "badgeText" to Schema.string(description = "Short offer badge like FREE 7-DAY VIP PASS or 40% OFF"),
            "whatsappMessage" to Schema.string(description = "Friendly personalized WhatsApp invite message with emojis")
        )
    )

    private val socialPromoSchema = Schema.obj(
        properties = mapOf(
            "headline" to Schema.string(description = "Catchy visual overlay headline for the Reel or Facebook post"),
            "reelHook" to Schema.string(description = "First 3-second viral spoken or on-screen hook for Instagram Reels"),
            "shotList" to Schema.string(description = "3 quick 5-second video clip ideas to film inside PowerHouse Gym"),
            "caption" to Schema.string(description = "High-converting Facebook and Instagram Reel caption with clear CTA"),
            "hashtags" to Schema.string(description = "10 targeted gym fitness hashtags separated by spaces")
        )
    )

    private val callScriptModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = callScriptSchema
            }
        )
    }

    private val whatsappModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = whatsappSchema
            }
        )
    }

    private val socialPromoModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = socialPromoSchema
            }
        )
    }

    private val textModel by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.8-flash")
    }

    suspend fun generateCallScript(
        contactName: String,
        goal: String,
        gymOffer: String
    ): Result<AiCallScript> {
        return try {
            val prompt = """
                You are Alex, the energetic AI Membership Concierge calling from PowerHouse Gym.
                Write a natural, friendly, conversational phone invitation script for a prospective member:
                - Prospect Name: $contactName
                - Fitness Goal: $goal
                - Featured Offer: $gymOffer
                Keep the total spoken script crisp (under 25 seconds to speak) so the prospect stays engaged.
            """.trimIndent()

            val response = withTimeout(60_000L) {
                callScriptModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("AI returned an empty script.")
            val json = JSONObject(raw)
            Result.success(
                AiCallScript(
                    greeting = json.getString("greeting"),
                    pitch = json.getString("pitch"),
                    objectionReply = json.getString("objectionReply"),
                    closingCta = json.getString("closingCta"),
                    summary = json.getString("summary")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI call script generation timed out", e)
            Result.failure(Exception("AI script generation timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI call script generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateLiveObjectionReply(
        contactName: String,
        goal: String,
        clientQuestion: String
    ): Result<String> {
        return try {
            val prompt = """
                You are Alex, the AI Voice Concierge on a live invitation call for PowerHouse Gym.
                Prospect: $contactName (Goal: $goal).
                The prospect just asked: "$clientQuestion".
                Reply in 2 concise, warm, spoken sentences that answer helpfully and invite them to book a free VIP trial tour today.
            """.trimIndent()

            val response = withTimeout(45_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (text.isNullOrBlank()) {
                Result.failure(Exception("AI returned an empty reply."))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Live objection reply timed out", e)
            Result.failure(Exception("AI reply timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Live objection reply failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateWhatsAppPosterCopy(
        offerTheme: String,
        contactName: String?
    ): Result<AiWhatsAppCopy> {
        return try {
            val recipientHint = if (contactName.isNullOrBlank()) {
                "a prospective gym member"
            } else {
                "a lead named $contactName"
            }
            val prompt = """
                Create a high-converting WhatsApp promotional poster headline and invitation message for PowerHouse Gym targeting $recipientHint.
                Offer focus: $offerTheme.
                Keep posterHeadline punchy (3 to 5 uppercase words) and badgeText short (2 to 4 words).
            """.trimIndent()

            val response = withTimeout(60_000L) {
                whatsappModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("AI returned empty WhatsApp copy.")
            val json = JSONObject(raw)
            Result.success(
                AiWhatsAppCopy(
                    posterHeadline = json.getString("posterHeadline"),
                    badgeText = json.getString("badgeText"),
                    whatsappMessage = json.getString("whatsappMessage")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "WhatsApp copy generation timed out", e)
            Result.failure(Exception("AI WhatsApp copy timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "WhatsApp copy generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateSocialPromoKit(
        platformLabel: String,
        gymOffer: String,
        theme: String
    ): Result<AiSocialPromoKit> {
        return try {
            val prompt = """
                Create a promotional social campaign for PowerHouse Gym for $platformLabel.
                Campaign Theme: $theme
                Offer: $gymOffer
                Provide a bold visual headline, a scroll-stopping 3-second Reels hook, a 3-clip shot list, an engaging caption, and 10 fitness hashtags.
            """.trimIndent()

            val response = withTimeout(60_000L) {
                socialPromoModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("AI returned empty promo kit.")
            val json = JSONObject(raw)
            Result.success(
                AiSocialPromoKit(
                    headline = json.getString("headline"),
                    reelHook = json.getString("reelHook"),
                    shotList = json.getString("shotList"),
                    caption = json.getString("caption"),
                    hashtags = json.getString("hashtags")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Social promo kit generation timed out", e)
            Result.failure(Exception("AI promo kit timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Social promo kit generation failed", e)
            Result.failure(e)
        }
    }

    private companion object {
        const val TAG = "GymAiService"
    }
}
