package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.io.File
import java.io.FileOutputStream

object PosterTemplates {
    val drawables = listOf(
        R.drawable.img_poster_strength,
        R.drawable.img_poster_hiit,
        R.drawable.img_poster_vip
    )
    val titles = listOf(
        "Iron Strength",
        "HIIT & Burn",
        "VIP Club"
    )
}

object PosterRendererAndShareHelper {

    fun renderPosterBitmap(
        context: Context,
        templateIndex: Int,
        headline: String,
        badgeText: String,
        offerDetails: String,
        clubContact: String
    ): Bitmap {
        val width = 1080
        val height = 1440
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val resId = PosterTemplates.drawables[templateIndex.coerceIn(0, PosterTemplates.drawables.lastIndex)]
        val bgRaw = BitmapFactory.decodeResource(context.resources, resId)
        if (bgRaw != null) {
            val scale = maxOf(width.toFloat() / bgRaw.width, height.toFloat() / bgRaw.height)
            val scaledW = bgRaw.width * scale
            val scaledH = bgRaw.height * scale
            val left = (width - scaledW) / 2f
            val top = (height - scaledH) / 2f
            val destRect = RectF(left, top, left + scaledW, top + scaledH)
            canvas.drawBitmap(bgRaw, null, destRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            bgRaw.recycle()
        } else {
            canvas.drawColor(Color.parseColor("#0B0D10"))
        }

        // Top & bottom atmospheric scrims for guaranteed typography contrast
        val topScrim = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, 520f,
                Color.argb(230, 11, 13, 16),
                Color.argb(0, 11, 13, 16),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 520f, topScrim)

        val bottomScrim = Paint().apply {
            shader = LinearGradient(
                0f, 640f, 0f, height.toFloat(),
                Color.argb(0, 11, 13, 16),
                Color.argb(245, 11, 13, 16),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 640f, width.toFloat(), height.toFloat(), bottomScrim)

        val displayTypeface = ResourcesCompat.getFont(context, R.font.barlow_condensed)
            ?: Typeface.DEFAULT_BOLD
        val bodyTypeface = ResourcesCompat.getFont(context, R.font.plus_jakarta_sans)
            ?: Typeface.DEFAULT

        // Volt top accent stripe
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4FF00")
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 14f, accentPaint)

        // Brand tag
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4FF00")
            textSize = 44f
            typeface = Typeface.create(displayTypeface, Typeface.BOLD)
            letterSpacing = 0.14f
        }
        canvas.drawText("POWERHOUSE GYM", 72f, 115f, brandPaint)

        // Badge pill
        val cleanBadge = badgeText.ifBlank { "FREE 7-DAY VIP PASS" }.uppercase()
        val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0B0D10")
            textSize = 34f
            typeface = Typeface.create(bodyTypeface, Typeface.BOLD)
        }
        val badgeBounds = Rect()
        badgeTextPaint.getTextBounds(cleanBadge, 0, cleanBadge.length, badgeBounds)
        val pillRect = RectF(
            72f,
            148f,
            72f + badgeBounds.width() + 56f,
            148f + 64f
        )
        canvas.drawRoundRect(pillRect, 32f, 32f, accentPaint)
        canvas.drawText(cleanBadge, 100f, 192f, badgeTextPaint)

        // Main Headline near lower third
        val cleanHeadline = headline.ifBlank { "UNLEASH YOUR STRENGTH" }.uppercase()
        val headlinePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 112f
            typeface = Typeface.create(displayTypeface, Typeface.BOLD)
        }
        val headlineLayout = StaticLayout.Builder
            .obtain(cleanHeadline, 0, cleanHeadline.length, headlinePaint, width - 144)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 0.96f)
            .setMaxLines(3)
            .build()

        canvas.save()
        canvas.translate(72f, 820f)
        headlineLayout.draw(canvas)
        canvas.restore()

        // Offer Details
        val cleanOffer = offerDetails.ifBlank {
            "24/7 Elite Equipment • Personal Trainers • HIIT Studio\nClaim your VIP trial session today."
        }
        val offerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D6DCE6")
            textSize = 36f
            typeface = bodyTypeface
        }
        val offerLayout = StaticLayout.Builder
            .obtain(cleanOffer, 0, cleanOffer.length, offerPaint, width - 144)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(6f, 1.1f)
            .setMaxLines(3)
            .build()

        val offerY = 820f + headlineLayout.height + 28f
        canvas.save()
        canvas.translate(72f, offerY)
        offerLayout.draw(canvas)
        canvas.restore()

        // Footer CTA Bar
        val barRect = RectF(72f, height - 180f, width - 72f, height - 72f)
        val barBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#18202B")
        }
        val barStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#D4FF00")
        }
        canvas.drawRoundRect(barRect, 24f, 24f, barBgPaint)
        canvas.drawRoundRect(barRect, 24f, 24f, barStrokePaint)

        val ctaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4FF00")
            textSize = 36f
            typeface = Typeface.create(bodyTypeface, Typeface.BOLD)
        }
        val footerText = clubContact.ifBlank { "BOOK YOUR FREE TRIAL • POWERHOUSE GYM" }
        canvas.drawText(footerText, 108f, height - 114f, ctaPaint)

        return bitmap
    }

    fun savePosterToCacheUri(context: Context, bitmap: Bitmap): Uri {
        val dir = File(context.cacheDir, "posters").apply { mkdirs() }
        val file = File(dir, "powerhouse_promo_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun sharePosterToWhatsApp(
        context: Context,
        posterUri: Uri,
        message: String,
        targetPhone: String? = null
    ) {
        copyToClipboard(context, "PowerHouse Promo", message)
        val whatsappPkg = when {
            isPackageInstalled(context, "com.whatsapp") -> "com.whatsapp"
            isPackageInstalled(context, "com.whatsapp.w4b") -> "com.whatsapp.w4b"
            else -> null
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, posterUri)
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (whatsappPkg != null) {
                setPackage(whatsappPkg)
                val digits = targetPhone?.filter { it.isDigit() }
                if (!digits.isNullOrBlank() && digits.length >= 7) {
                    putExtra("jid", "$digits@s.whatsapp.net")
                }
            }
        }

        try {
            if (whatsappPkg != null) {
                context.startActivity(intent)
            } else {
                Toast.makeText(
                    context,
                    "WhatsApp not found on device — opening Share Sheet",
                    Toast.LENGTH_SHORT
                ).show()
                context.startActivity(Intent.createChooser(intent, "Send Gym Poster"))
            }
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, posterUri)
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(fallback, "Send Gym Poster"))
        }
    }

    fun openWhatsAppDirectChat(context: Context, phone: String, message: String) {
        val digits = phone.filter { it.isDigit() }
        if (digits.length < 7) {
            Toast.makeText(context, "Enter a valid phone number with country code", Toast.LENGTH_SHORT).show()
            return
        }
        val url = "https://wa.me/$digits?text=${Uri.encode(message)}"
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to open WhatsApp chat link", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareToInstagramReelOrPost(
        context: Context,
        mediaUri: Uri,
        isVideo: Boolean,
        fullCaption: String
    ) {
        copyToClipboard(context, "Instagram Caption", fullCaption)
        val igInstalled = isPackageInstalled(context, "com.instagram.android")
        val mime = if (isVideo) "video/*" else "image/png"

        if (igInstalled) {
            Toast.makeText(
                context,
                "Caption & hashtags copied! Paste them in your Instagram Reel.",
                Toast.LENGTH_LONG
            ).show()
            val reelIntent = Intent("com.instagram.share.ADD_TO_REEL").apply {
                setDataAndType(mediaUri, mime)
                putExtra(Intent.EXTRA_STREAM, mediaUri)
                setPackage("com.instagram.android")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, mediaUri)
                putExtra(Intent.EXTRA_TEXT, fullCaption)
                setPackage("com.instagram.android")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                if (isVideo && reelIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(reelIntent)
                } else {
                    context.startActivity(sendIntent)
                }
                return
            } catch (_: Exception) {
                // Fall through to system share sheet
            }
        } else {
            Toast.makeText(
                context,
                "Instagram not installed — caption copied, opening Share Sheet",
                Toast.LENGTH_LONG
            ).show()
        }

        val fallback = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, mediaUri)
            putExtra(Intent.EXTRA_TEXT, fullCaption)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(fallback, "Share Instagram Reel / Promo"))
    }

    fun shareToFacebook(
        context: Context,
        mediaUri: Uri,
        isVideo: Boolean,
        fullCaption: String
    ) {
        copyToClipboard(context, "Facebook Caption", fullCaption)
        val fbInstalled = isPackageInstalled(context, "com.facebook.katana")
        val mime = if (isVideo) "video/*" else "image/png"

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, mediaUri)
            putExtra(Intent.EXTRA_TEXT, fullCaption)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (fbInstalled) {
                setPackage("com.facebook.katana")
            }
        }

        try {
            if (fbInstalled) {
                Toast.makeText(
                    context,
                    "Promo caption copied — opening Facebook!",
                    Toast.LENGTH_SHORT
                ).show()
                context.startActivity(intent)
            } else {
                Toast.makeText(
                    context,
                    "Facebook not installed — caption copied, opening Share Sheet",
                    Toast.LENGTH_LONG
                ).show()
                context.startActivity(Intent.createChooser(intent, "Share to Facebook"))
            }
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, mediaUri)
                putExtra(Intent.EXTRA_TEXT, fullCaption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(fallback, "Share to Facebook"))
        }
    }

    fun dialPhoneNumber(context: Context, phone: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}"))
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "No dialer app available", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            true
        } catch (_: Exception) {
            try {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }
    }
}
