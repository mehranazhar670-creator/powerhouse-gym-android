const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const nowTs = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_gym_owner";
const BOB_UID = "bob_other_owner";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validContact(userId) {
  return {
    userId,
    name: "Rahul Sharma",
    phone: "+919876543210",
    goal: "Strength",
    status: "new",
    callsTodayCount: 0,
    totalCallsCount: 0,
    lastCalledDate: "",
    posterSent: false,
    notes: "Interested in evening batch",
    createdAt: nowTs(),
    updatedAt: nowTs(),
  };
}

test("Unauthenticated user cannot list or write contacts", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("contacts").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("contacts").doc("c1").set(validContact(ALICE_UID))
  );
});

test("Owner can create, list, and update their contact", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("contacts").doc("contact_1");
  await assertSucceeds(ref.set(validContact(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("contacts").get());
  await assertSucceeds(ref.update({ posterSent: true, updatedAt: nowTs() }));
});

test("Cross-user access to contacts is denied", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(ALICE_UID).collection("contacts").doc("contact_1").set(validContact(ALICE_UID));
  });
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("contacts").doc("contact_1").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("contacts").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("contacts").doc("contact_2").set(validContact(BOB_UID)));
});

test("Shadow update with ghost field is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("contacts").doc("contact_1");
  await assertSucceeds(ref.set(validContact(ALICE_UID)));
  await assertFails(ref.update({ isAdmin: true, updatedAt: nowTs() }));
});

test("Daily quota enforces max 2 attended invitation calls per day", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const quotaRef = aliceDb.collection("users").doc(ALICE_UID).collection("daily_quotas").doc("2026-11-15");

  await assertSucceeds(
    quotaRef.set({
      userId: ALICE_UID,
      dateKey: "2026-11-15",
      callsAttended: 2,
      postersSent: 5,
      reelsShared: 1,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  // Exceeding daily limit of 2 calls MUST fail at rules layer
  await assertFails(
    quotaRef.update({
      callsAttended: 3,
      updatedAt: nowTs(),
    })
  );
});

test("Call logs are immutable (update and delete denied)", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const logRef = aliceDb.collection("users").doc(ALICE_UID).collection("call_logs").doc("log_1");

  await assertSucceeds(
    logRef.set({
      userId: ALICE_UID,
      contactId: "contact_1",
      contactName: "Rahul Sharma",
      contactPhone: "+919876543210",
      dateKey: "2026-11-15",
      outcome: "attended",
      aiScriptSummary: "Invited for 7-day free strength pass",
      durationSeconds: 45,
      createdAt: nowTs(),
    })
  );

  await assertFails(logRef.update({ outcome: "no_answer" }));
  await assertFails(logRef.delete());
});

test("Promo campaigns validate platform and owner", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const promoRef = aliceDb.collection("users").doc(ALICE_UID).collection("promo_campaigns").doc("promo_1");

  await assertSucceeds(
    promoRef.set({
      userId: ALICE_UID,
      platform: "instagram_reel",
      headline: "FREE 7-DAY VIP PASS",
      caption: "Transform your mornings at PowerHouse Gym!",
      reelHook: "POV: You walked into PowerHouse Gym at 6 AM",
      hashtags: "#PowerHouseGym #GymReels",
      templateIndex: 0,
      sharedCount: 1,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  await assertFails(
    promoRef.update({
      platform: "invalid_network",
      updatedAt: nowTs(),
    })
  );
});
